# gridsearch_durables.jl — robust driver (script style)

# --- headless + sane threading ---
ENV["GKSwstype"] = "nul"
ENV["OPENBLAS_NUM_THREADS"] = "1"
ENV["MKL_NUM_THREADS"]     = "1"
ENV["OMP_NUM_THREADS"]      = "1"

using Random, Distributions, Statistics, Printf, DelimitedFiles, LinearAlgebra
using Plots, JLD2, StatsBase, KernelDensity, DataFrames, CSV, PrettyTables

include("durable_mod.jl")
include("collectfunctions.jl")
include("simann.jl")
include("gmmfunctions_broad.jl")

using Main.sz, Main.kst, Main.settings, Main.dtp, Main.globals

const EPS = 1e-12
const seed     = 1924        # <-- define seed
const n_trials = 2000           # <-- define trials


# ----------------- Script body -----------------
println("Host: $(gethostname())  Threads: $(Threads.nthreads())")
Random.seed!(seed)

# Flags
restart  = false
doiters  = false

# Starting values and bounds (SHORT vector)
x_start = zeros(sz.noestp)
x_start[1] = 0.50   # nu
x_start[2] = 0.05   # f_d
x_start[3] = 0.02   # kappa

lb = zeros(sz.noestp);  ub = zeros(sz.noestp)
lb[1] = 0.35;  ub[1] = 0.95
lb[2] = 0.005; ub[2] = 0.40
lb[3] = 0.001; ub[3] = 0.50
pea = buildparam(x_start)
moms = momentgen(pea)
println("Running baseline simulation…")

Random.seed!(seed)
# Random search
x_opt = copy(x_start)
f_opt = fcn(x_opt, 1e12)     # uses buildparam internally
println("Starting search with x_start = ", x_start, ", f(x_start) = ", f_opt)

for i in 2:n_trials
    x = lb .+ (ub .- lb) .* rand(sz.noestp)
    #smoke_test(x; verbose=false) || continue
    f = fcn(x, f_opt)
    if isfinite(f) && f < f_opt
        global x_opt = copy(x)
        global f_opt = f
        println("New optimum at trial $i: x = ", x_opt, ", f = ", f_opt)
    end
end

println("\n✅ Optimization finished")
println("Optimal parameters: ", x_opt)
println("Function value at optimum: ", f_opt)

if isfinite(f_opt)
    stats = smmstats(x_opt)
    print_smm_results(stats, x_opt)
else
    @warn "Best objective is not finite; skipping SMM standard errors."
end
